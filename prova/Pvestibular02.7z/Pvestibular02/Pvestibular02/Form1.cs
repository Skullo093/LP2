﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstVestibular.Items.Clear();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            int[,] alunos = new int[2,5];
            string aux = "";

            for (int i=0; i < 2; i++)
                for (int j=0; j<5; j++)
                {
                    aux = Interaction.InputBox($"Curso {i + 1}, Digite a quantidade de alunos no ano {j + 1}", "Entrada de dados ");
                    if (!int.TryParse(aux, out alunos[i,j]) ||
                            ( alunos[i,j] < 0 ))
                    {
                        MessageBox.Show("Valor Inválido!!");
                        j--;
                    }
                    if (aux == "") 
                    {
                        break;
                    }
                }
            ArrayList TotalAlunos = new ArrayList();
            int QtdAlunos = 0;
            int QtdCurso;
            for (int k = 0; k < 2; k++)

            {
                QtdCurso = 0;
                QtdCurso = alunos[k,0] + alunos[k,1] + alunos[k,2] + alunos[k,3] + alunos[k,4];
                TotalAlunos.Add($"Total do Curso {k + 1} no ano 1: {alunos[k, 0].ToString()}" +
                $"\nTotal do Curso {k + 1} no ano 2: {alunos[k, 1].ToString()}" +
                $"\nTotal do Curso {k + 1} no ano 3: {alunos[k, 2].ToString()}" +
                $"\nTotal do Curso {k + 1} no ano 4: {alunos[k, 3].ToString()}" +
                $"\nTotal do Curso {k + 1} no ano 5: {alunos[k, 4].ToString()}" +
                $"\nTotal Curso: {QtdCurso.ToString()}\n\n"); 
                QtdAlunos += alunos[k, 0] + alunos[k, 1] + alunos[k, 2] + alunos[k, 3] + alunos[k, 4];
                lstVestibular.Items.Add(TotalAlunos[k]);
            }
            lstVestibular.Items.Add($"\nTotal Geral de Alunos em todos os cursos em todos os anos: {QtdAlunos.ToString()}");
        }
    }
}
