﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out double a))
            {
                errorProvider1.SetError(txtNum1, "NUMERO INVALIDO!!!!!!!!!");
                txtNum1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNum1, "");
            }
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out double a))
            {
                errorProvider2.SetError(txtNum2, "NUMERO INVALIDO!!!!!!!!!");
                txtNum2.Focus();
            }
            else
            {
                errorProvider2.SetError(txtNum2, "");
            }
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int num1, num2;
            if ((!int.TryParse(txtNum1.Text, out num1)) ||
                (!int.TryParse(txtNum2.Text, out num2)) ||
                (num1 <= num2))
            {
                MessageBox.Show("DADOS INVALIDOS");
            }
            else
            {
                Random obj1 = new Random();
                int Sorteado = obj1.Next(num1, num2);
                MessageBox.Show(Sorteado.ToString());
            }
        }
    }
}
