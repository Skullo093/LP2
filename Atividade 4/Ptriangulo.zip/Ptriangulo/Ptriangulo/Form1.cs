﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double a, b, c;

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtB.Text, out b) || b <= 0 || txtB.Text == "")
            {
                MessageBox.Show("Valor inválido");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtC.Text, out c) || c <= 0 || txtC.Text == "")
            {
                MessageBox.Show("Valor inválido");
                txtC.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
               "Saída", MessageBoxButtons.YesNo,
               MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (Math.Abs(b - c) <a && a < b + c
                || Math.Abs(a - c) < b && b < a + c
                || Math.Abs(a - b) < c && c < a + b)
            {
                if (a == b && a == c )
                {
                    MessageBox.Show("Este triângulo é equilátero");
                }
                else if (a == b || a == c || b == c)
                {
                    MessageBox.Show("Este triângulo é isóceles");
                }
                else
                {
                    MessageBox.Show("Este triângulo é escaleno");
                }
            }
            else
            {
                MessageBox.Show("Impossivel fazer este triângulo!");
            }
        }

        public Form1()
        {
            InitializeComponent();
            //double.Parse(txtA.Text = a.ToString());
            //double.Parse(txtB.Text = b.ToString());
            //double.Parse(txtC.Text = c.ToString());
        }

        private void textBox3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtA.Text, out a) || a <= 0 || txtA.Text == "")
            {
                MessageBox.Show("Valor inválido");
                txtA.Focus();
            }
        }
    }
}
