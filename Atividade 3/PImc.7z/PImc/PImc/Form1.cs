﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskAltura.Text, out altura) || altura <= 0)
            {
                errorProvider2.SetError(mskAltura, "Altura inválida");
                mskAltura.Focus();
            }
            else
            {
                errorProvider2.SetError(mskAltura, "");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mskAltura.Clear();
            mskPeso.Clear();
            txtIMC.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double imc;
            altura = Math.Pow(altura, 2);
            txtIMC.Text = (peso / altura).ToString("N2");
            Double.TryParse(txtIMC.Text, out imc);
            imc = Math.Round(imc, 1);
            if (imc <18.5)
            {
                MessageBox.Show("Magreza" +
                    " Obesidade grau 0");
            }
            else if (imc < 24.9)
            {
                MessageBox.Show("Normal" +
                    " Obesidade grau 0");
            }
            else if (imc < 29.9)
            {
                MessageBox.Show("Sobrepeso" +
                    " Obesidade grau |");
            }
            else if (imc < 39.9)
            {
                MessageBox.Show("Obesidade" +
                    " Obesidade grau ||");
            }
            else
                MessageBox.Show("Obesidade grave" +
                    " Obesidade grau |||");
        }

        private void mskPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskPeso.Text, out peso)|| peso <= 0)
            {
                errorProvider1.SetError(mskPeso, "Peso inválido");
                mskPeso.Focus();
            }
            else
            {
                errorProvider1.SetError(mskPeso, "");
            }
        }
    }
}
