﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContatos0030482511034
{
    internal class Cidade
    {
        private string ufcidade;
        private string nomecidade;
        private int idcidade;

        public string Ufcidade
        {
            get
            {
                return ufcidade;
            }
            set
            {
                Ufcidade = value;
            }
        }
        public string Nomecidade
        {
            get
            {
                return nomecidade;
            }
            set
            {
                nomecidade = value; 
            }
        }
        public int Idcidade
        {
            get
            {
                return idcidade;   
            }
            set
            {
                idcidade = value;
            }
        }
        public DataTable Listar()
        {
            SqlDataAdapter daCidade;

            DataTable dtCidade= new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("SELECT * FROM CIDADE ORDER BY NOME_CIDADE",
                    frmPrincipal.conexao);
                daCidade.Fill(dtCidade);
                daCidade.FillSchema(dtCidade, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtCidade;
        }
    }
}
